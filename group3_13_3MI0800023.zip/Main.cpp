#include "Human.hpp"

int main()
{
  Human* human = new Human();
}