#ifndef __WARRIOR_HPP__
#define __WARRIOR_HPP__

#define WARRIOR_STRENGTH 40
#define WARRIOR_MANA     10
#define WARRIOR_HEALTH   50

#include "Hero.hpp"

class Warrior : public Hero
{
  Warrior();
};

#endif