#ifndef __MAGE_HPP__
#define __MAGE_HPP__

#define MAGE_STRENGTH 10
#define MAGE_MANA     40
#define MAGE_HEALTH   50

#include "Hero.hpp"

class Mage : public Hero
{
  Mage();
};

#endif